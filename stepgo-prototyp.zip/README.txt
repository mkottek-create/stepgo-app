STEPGO – INTERAKTIVER PROTOTYP (NOVEMBER 2026)

Starten: index.html in einem modernen Browser öffnen. Zum Online-Stellen alle Dateien dieses Ordners zusammen bei einem Webhost wie Netlify veröffentlichen (ZIP vorher entpacken).

Funktionen:
- modernes responsives StepGo-Design
- tägliche Demo-Schrittanzeige, Fortschrittsring, einstellbares Tagesziel
- 1 Test-Coin je 100 Demo-Schritte, maximal 200 Test-Coins pro Tag
- Coins täglich höchstens einmal bestätigen; Tagesbestätigungen protokollieren
- einfache Bereiche Start/Schritte/Prämien/Profil
- Testdaten lokal im Browser speichern
- Demo-Schritte hinzufügen und zurücksetzen; lokale Daten löschen

WICHTIG: Echte automatische Schritte (Apple Health / Android Health Connect) sind NICHT integriert. Dafür wird eine native iOS-/Android-App mit Nutzerfreigabe und einer sicheren Server-Anbindung benötigt. Coins sind rein virtuell und können nicht ausgezahlt werden.

Der Name StepGo ist ein Projekt-Arbeitstitel, keine Zusage über Markenverfügbarkeit.
